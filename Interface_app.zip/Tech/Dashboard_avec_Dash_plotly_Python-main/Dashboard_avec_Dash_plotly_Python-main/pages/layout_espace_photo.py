import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
from components.functions import df_pc
from datetime import date, timedelta
import dash_table
from datetime import datetime as dt
import cv2

#camera de l'ordi
port = 1

ramp_frames = 30

#etabliseement de la cam
camera = cv2.VideoCapture(port)
#capture
def get_image():
    retval, im = camera.read()
    return im

# for i in range(ramp_frames):
temp = get_image()
print("Capturing Face......") 

#prendre la photo
camera_capture = get_image()
file = "test_image.png"
cv2.imwrite(file,camera_capture)



body = dbc.Container([
        html.Br(),
        dbc.Row(
                [
                dbc.Col(

                    html.Div(
                        [   html.Br([]),
                           
                            #html.Br([]),
                            
                            
                        ]

                         )

                ,style={'color':'blue','backgroundColor':'white'})
                    ], justify="center", align="center"
                    ),
     html.Br(),
     #dbc.Row([dbc.Col(date_picker, lg=4),dbc.Col(table, lg=8)]),
],style={"height": "100vh"}
)

layout_espace_photo =  html.Div([body],style={'background-image': 'url("/assets/pollution-dechets-plastiques-tripler-20-ans.jpg")'})

#])
