import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
from components.functions import df_pc
from datetime import date, timedelta
import dash_table
from datetime import datetime as dt


body = dbc.Container([
        html.Br(),
        dbc.Row(
                [
                dbc.Col(

                    html.Div(
                        [   html.Br([]),
                            html.H5("NoWasteam!!!",style={'color':'green','backgroundColor':'gray'}),
                            html.Br([]),
                            html.P(
                                "\
                            Nous sommes NoWasteam, un groupe mixte d'élèves ingénieur de l'efrei Paris, actuellement en 1ère annéee \
                            de cycle ingénieur.Cependant en vue de commencer un stage technique en novembre 2021\
                            Nous avons participé à un MasterCamp afin de disposer de ressources nécessaire pour le bon déroulement\
                            du stage. A cet effet nous devions repondre a cette appel d'offre de Surfinder." ,
                               
                               style={'color' : 'green'},

                               #dbc.Row(
                                #[
                                    #Navlink dashbord
                                   # dbc.NavLink("Accès Dashbsoard", href="/dashboard",style={'color':'blue'})

                            ),
                            #html.P(
                              #  "\
                            #Ces données ont par la suite été transformées pour interagir dynamiquement avec des graphiques. \
                            #On y affiche des informations telles que: le nombre total d'accès à la plateform par appareil ,  \
                       # les graphiques d'évolution des accès par appareil , par type d'appareil et par système d'exploitation sur plusieurs mois et années.\
                        #Vous pouvez accéder au dashboard via la barre de navigation ou en cliquant directement ci-dessous.",


                           #     style={"color": "#000406"},

                           # ),
                            dbc.Row(
                                [
                                    #Navlink dashbord
                                   dbc.NavLink("Accès Contact", href="/contact",style={'color':'blue'})
                                    
                                ])
                        ]

                         )

                ,style={'color':'blue','backgroundColor':'white'})
                    ], justify="center", align="center"
                    ),
     html.Br(),
     #dbc.Row([dbc.Col(date_picker, lg=4),dbc.Col(table, lg=8)]),
],style={"height": "100vh"}
)

layout_presentation =  html.Div([body],style={'background-image': 'url("/assets/pollution-dechets-plastiques-tripler-20-ans.jpg")'})

#])
