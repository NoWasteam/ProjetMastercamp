import dash
import dash_bootstrap_components as dbc
import dash_html_components as html
import cv2

#Camera de l'ordi
port = 0

ramp_frames=30

#etablissement de la camera
camera = cv2.VideoCapture(port)
def get_image():
    retval, im = camera.read()
    return im

#for i in range(ramp_frames):
    temp = get_image()
#print("capturing face")



LOGO = "../assets/pollution-dechets-plastiques-tripler-20-ans.jpg"
navbar = dbc.Navbar(
    [
        html.A(
            # Alignement vertical de l'image et de l'acceuil
            dbc.Row(
                [   #logo
                    dbc.Col(html.Img(src=LOGO, height="40px")),
                    #Navlink Acceuil
                    dbc.NavLink("Accueil", href="/acceuil",style={'color':'white'}),
                    #Navlink dashbord
                    dbc.NavLink("Dashboard", href="/dashboard",style={'color':'white'}),
                     #Navlink presentation
                    dbc.NavLink("Qui sommes nous?", href="/presentation",style={'color':'white'}),
                     #Navlink espace_photo
                    dbc.NavLink("Espace_photo", href="/espace_photo",style={'color':'white'}),
                     #Navlink contact
                    dbc.NavLink("Contacts", href="/contact",style={'color':'white'})

                ],
                align="center",
                no_gutters=True,
            ),
        ),
        dbc.NavbarToggler(id="navbar-toggler"),
    ],
    color="dark",
    dark=True,
)
