import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import callbacks
from pages.header import navbar
from pages.layout_dashboard import layout_dashboard
from pages.layout_acceuil import layout_acceuil
from pages.layout_presentation import layout_presentation
from pages.layout_contact import layout_contact
from pages.layout_espace_photo import layout_espace_photo
from app import app,server


#layout rendu par l'application
app.layout = html.Div([
    dcc.Location(id='url', refresh=True),
    navbar,
    html.Div(id='page-content')
])

#callback pour mettre à jour les pages
@app.callback(Output('page-content', 'children'),
              [Input('url', 'pathname')])
def display_page(pathname):
    if pathname=='/acceuil' or pathname=='/':
        return layout_acceuil
    elif pathname=='/dashboard':
        return layout_dashboard
    elif pathname=='/presentation':
        return layout_presentation
    elif pathname=='/espace_photo':
        return layout_espace_photo
    elif pathname=='/contact':
        return layout_contact


if __name__ == '__main__':
    app.run_server(debug=True)
